/* eslint-disable @typescript-eslint/no-explicit-any */

export interface Group {
  id?: number;
  active?: boolean;
  disabled?: boolean;
  value: any;
}
